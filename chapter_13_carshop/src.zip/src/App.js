import Carlist from './components/Carlist';
import './App.css';

function App() {
  return (
    <div className="App">
      <Carlist />
    </div>
  );
}

export default App;